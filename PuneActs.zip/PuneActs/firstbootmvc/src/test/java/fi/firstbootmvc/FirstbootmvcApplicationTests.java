package fi.firstbootmvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstbootmvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
