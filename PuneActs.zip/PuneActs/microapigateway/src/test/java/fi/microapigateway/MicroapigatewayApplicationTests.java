package fi.microapigateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroapigatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
