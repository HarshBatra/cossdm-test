package fi.bootsecuredform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootsecuredformApplicationTests {

	@Test
	void contextLoads() {
	}

}
