package com.cdac.firstSpringBootRESTHiber;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstSpringBootRestHiberApplicationTests {

	@Test
	void contextLoads() {
	}

}
