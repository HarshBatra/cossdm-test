package com.cdac.firstSpringBootRESTHiber;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;

@SpringBootApplication(scanBasePackages = {"com.cdac.controllers", "com.cdac.services"})
@EntityScan(basePackages = {"com.cdac.entity"})
public class FirstSpringBootRestHiberApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstSpringBootRestHiberApplication.class, args);
	}

}
