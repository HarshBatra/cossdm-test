package com.cdac.services;

import java.util.List;

import com.cdac.dto.CategoryDTO;

public interface CategoryService {
	public boolean addNewCategory(CategoryDTO dto);
	public CategoryDTO getCategoryById(int categoryId);
	public List<CategoryDTO> allCategories();
}
