package com.cdac.services;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dto.CategoryDTO;
import com.cdac.entity.Category;


@Service
public class CategoryServiceImpl implements CategoryService{
	
	@Autowired
	SessionFactory hibFactory;

	@Override
	public boolean addNewCategory(CategoryDTO dto) {
		Category entityCategory = new Category();
		BeanUtils.copyProperties(dto, entityCategory);
		
		try (Session hibSession = hibFactory.openSession()) {
			hibSession.beginTransaction();
			hibSession.persist(entityCategory);
			hibSession.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return true;
	}

	@Override
	public CategoryDTO getCategoryById(int categoryId) {
		try (Session hibSession = hibFactory.openSession()){
			Category entityCategory = (Category) hibSession.get(Category.class, categoryId);
			CategoryDTO dto = new CategoryDTO();
			BeanUtils.copyProperties(entityCategory, dto);
			return dto;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<CategoryDTO> allCategories() {
		try (Session hibSession = hibFactory.openSession()) {
			Query<Category> qrCategory = hibSession.createQuery("from Category", Category.class);
			List<Category> list = qrCategory.getResultList();
			ArrayList<CategoryDTO> finalList = new ArrayList<>();
			
			for (Category eCategory : list) {
				CategoryDTO dto = new CategoryDTO();
				BeanUtils.copyProperties(eCategory, dto);
				finalList.add(dto);
			}
			
			return finalList;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
}
