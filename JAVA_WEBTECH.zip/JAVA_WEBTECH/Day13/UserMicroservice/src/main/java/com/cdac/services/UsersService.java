package com.cdac.services;

import java.util.List;

import com.cdac.dto.UsersDTO;

public interface UsersService {
	public UsersDTO getUsersDetails(String userName);
	public List<UsersDTO> allUsers();
}
