package com.cdac.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cdac.dto.UsersDTO;
import com.cdac.services.UsersService;

@RestController
@RequestMapping("/users")
public class UsersController {
	
	@Autowired
	UsersService usersService;
	
	@GetMapping("/allUsers")
	public List<UsersDTO> getAllUsers(){
		return usersService.allUsers();
	}
	
	@GetMapping("getUserDetails")
	public UsersDTO getUserDetails(@RequestParam("uName") String uName) {
		return usersService.getUsersDetails(uName);
	}
}
