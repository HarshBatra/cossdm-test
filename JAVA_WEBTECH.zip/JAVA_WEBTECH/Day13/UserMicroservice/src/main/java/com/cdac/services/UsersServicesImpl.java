package com.cdac.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dto.UsersDTO;
import com.cdac.entity.Users;
import com.cdac.repositories.UsersRepository;

@Service
public class UsersServicesImpl implements UsersService{
	
	@Autowired
	UsersRepository repository;

	@Override
	public UsersDTO getUsersDetails(String userName) {
		Users eUser = repository.findById(userName).get();
		UsersDTO dto = new UsersDTO();
		BeanUtils.copyProperties(eUser, dto);
		return dto;
	}

	@Override
	public List<UsersDTO> allUsers() {
		List<Users> list = (List<Users>) repository.findAll();
		ArrayList<UsersDTO> finalList = new ArrayList<>();
		for (Users eUser: list) {
			UsersDTO dto = new UsersDTO();
			BeanUtils.copyProperties(eUser, dto);
			finalList.add(dto);
		}
		return finalList;
	}

}
