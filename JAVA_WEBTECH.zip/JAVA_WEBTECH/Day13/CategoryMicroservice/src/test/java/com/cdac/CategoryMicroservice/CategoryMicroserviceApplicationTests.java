package com.cdac.CategoryMicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CategoryMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
