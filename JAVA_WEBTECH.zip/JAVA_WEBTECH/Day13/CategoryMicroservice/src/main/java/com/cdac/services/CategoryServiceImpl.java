package com.cdac.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dto.CategoryDTO;
import com.cdac.entity.Category;
import com.cdac.repositories.CategoryRepository;

@Service
public class CategoryServiceImpl implements CategoryService{
	
	@Autowired
	CategoryRepository repository;

	@Override
	public boolean addNewCategory(CategoryDTO dto) {
		Category eCat = new Category();
		BeanUtils.copyProperties(dto, eCat);
		repository.save(eCat);
		return true;
	}

	@Override
	public CategoryDTO getCategoryById(int catId) {
		Category eCat = repository.findById(catId).get();
		CategoryDTO dto = new CategoryDTO();
		BeanUtils.copyProperties(eCat, dto);
		return dto;
	}

	@Override
	public List<CategoryDTO> allCategories() {
		List<Category> list = (List<Category>) repository.findAll();
		ArrayList<CategoryDTO> finalList = new ArrayList<>();
		for (Category eCat : list) {
			CategoryDTO dto = new CategoryDTO();
			BeanUtils.copyProperties(eCat, dto);
			finalList.add(dto);
		}
		return finalList;
	}

	@Override
	public List<CategoryDTO> getCategoryNameLike(String nameLike) {
		List<Category> list = (List<Category>) repository.getCategoriesWithNameLike(nameLike);
		ArrayList<CategoryDTO> finalList = new ArrayList<>();
		for (Category eCat : list) {
			CategoryDTO dto = new CategoryDTO();
			BeanUtils.copyProperties(eCat, dto);
			finalList.add(dto);
		}
		return finalList;
	}
	
}
