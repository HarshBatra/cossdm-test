package com.cdac.services;

import java.util.List;

import com.cdac.dto.CategoryDTO;

public interface CategoryService {
	public boolean addNewCategory(CategoryDTO dto);
	public CategoryDTO getCategoryById(int catId);
	public List<CategoryDTO> allCategories();
	public List<CategoryDTO> getCategoryNameLike(String nameLike);
}
