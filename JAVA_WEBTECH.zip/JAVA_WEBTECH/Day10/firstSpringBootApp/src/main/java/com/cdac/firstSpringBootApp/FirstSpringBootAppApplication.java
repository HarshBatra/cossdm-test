package com.cdac.firstSpringBootApp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.cdac.beans.Users;

@SpringBootApplication(scanBasePackages = {"com.cdac.beans"})
public class FirstSpringBootAppApplication implements CommandLineRunner{

	@Autowired
	Users objUser;
	
	public static void main(String[] args) {
		SpringApplication.run(FirstSpringBootAppApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		objUser.setUserName("harsh");
		objUser.setPassword("harsh1234");
		System.out.println(objUser);
	}
}
