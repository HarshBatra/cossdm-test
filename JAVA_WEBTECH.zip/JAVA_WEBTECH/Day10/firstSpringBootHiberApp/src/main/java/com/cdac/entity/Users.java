package com.cdac.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="users")
public class Users {
	@Id
	@Column(name="username")
	String userName;
	
	@Column(name="password")
	String password;
	
	@Column(name="email")
	String email;
	
	@Column(name="name")
	String name;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public Users() {}

	public Users(String userName, String password, String email, String name) {
		super();
		this.userName = userName;
		this.password = password;
		this.email = email;
		this.name = name;
	}

	@Override
	public String toString() {
		return "Users [userName=" + userName + ", password=" + password + ", email=" + email + ", name=" + name + "]";
	}
	
	
}
