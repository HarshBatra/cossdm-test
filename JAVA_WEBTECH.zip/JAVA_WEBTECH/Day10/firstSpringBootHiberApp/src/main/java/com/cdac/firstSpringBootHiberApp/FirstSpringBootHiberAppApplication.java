package com.cdac.firstSpringBootHiberApp;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;

import com.cdac.entity.Users;

@SpringBootApplication
@EntityScan(basePackages = {"com.cdac.entity"})
public class FirstSpringBootHiberAppApplication implements CommandLineRunner{

	@Autowired
	SessionFactory hibFactory;
	
	public static void main(String[] args) {
		SpringApplication.run(FirstSpringBootHiberAppApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		try(Session hibSession = hibFactory.openSession()){
			Users objUser = (Users) hibSession.get(Users.class, "harsh");
			System.out.println(objUser);
		}
	}

}
