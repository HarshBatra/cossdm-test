package com.cdac.firstSpringBootHiberApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstSpringBootHiberAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
