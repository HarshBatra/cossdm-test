package com.cdac.firstSpringBootMVCHiber;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;

@SpringBootApplication(scanBasePackages = {"com.cdac.controllers"})
@EntityScan(basePackages = {"com.cdac.entity"})
public class FirstSpringBootMvcHiberApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstSpringBootMvcHiberApplication.class, args);
	}

}
