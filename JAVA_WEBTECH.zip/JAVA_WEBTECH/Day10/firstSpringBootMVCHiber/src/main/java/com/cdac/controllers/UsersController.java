package com.cdac.controllers;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cdac.entity.Users;


@Controller
public class UsersController {
	@Autowired
	SessionFactory hibFactory;
	
	@RequestMapping("/login")
	public void prepareUsers(Model data) {
		Users objUser = new Users();
		data.addAttribute("objUser", objUser);
	}
	
	@RequestMapping("/authenticate")
	public ModelAndView authenticate(@ModelAttribute("objUser") Users objUser) {
		try (Session hibSession = hibFactory.openSession()){
			Users dbUsers = (Users) hibSession.get(Users.class, objUser.getUserName());
			
			if (dbUsers.getPassword().equals(objUser.getPassword()))
				return new ModelAndView("welcome", "data", "welcome to online shopping app");
			else 
				return new ModelAndView("failure", "data", "Please login again");
		}
	}
}
