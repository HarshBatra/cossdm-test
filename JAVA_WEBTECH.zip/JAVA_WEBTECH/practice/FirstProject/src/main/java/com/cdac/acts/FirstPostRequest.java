package com.cdac.acts;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class FirstPostRequest extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter out = resp.getWriter();
		Enumeration<String> headers = req.getHeaderNames();
		out.println("<html>");
		out.println("<body>");
		out.println("<table border=1>");
		out.println("<tr>");
		out.println("<th>Key</th>");
		out.println("<th>Value</th>");
		out.println("</tr>");
		while(headers.nextElement() != null) {
			String headername = headers.nextElement();
			String headervalue = req.getHeader(headername);
			out.println("<tr>");
			out.println("<td>"+headername+"</td>");
			out.println("<td>"+headervalue+"</td>");
			out.println("</tr>");
		}
		out.println("</table>");
		out.println("</body>");
		out.println("</html>");
	}
}
