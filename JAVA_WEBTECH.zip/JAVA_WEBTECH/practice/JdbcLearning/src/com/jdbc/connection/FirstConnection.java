package com.jdbc.connection;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class FirstConnection {
	public static void main(String[] args) throws SQLException, FileNotFoundException, IOException {
		
		Properties prop = new Properties();
		prop.load(new FileInputStream("DB.properties"));
		
		String dbUrl = prop.getProperty("conn.DBUrl");
		String dbuser = prop.getProperty("conn.user");
		String dbpassword = prop.getProperty("conn.password");
		
		Connection conn = DriverManager.getConnection(dbUrl, dbuser, dbpassword);
		Statement stSelect = conn.createStatement();
		ResultSet result = stSelect.executeQuery("select * from users");
		
		while(result.next()) {
			System.out.print(result.getString(1)+" ");
			System.out.print(result.getString(2)+" ");
			System.out.print(result.getString(3)+" ");
		}
	}
}