package com.jdbc.connection;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;

public class PrepSt {
	public static void main(String[] args) throws SQLException, FileNotFoundException, IOException {

		Properties prop = new Properties();
		prop.load(new FileInputStream("DB.properties"));

		String dbUrl = prop.getProperty("conn.DBUrl");
		String dbuser = prop.getProperty("conn.user");
		String dbpassword = prop.getProperty("conn.password");

		try (Connection conn = DriverManager.getConnection(dbUrl, dbuser, dbpassword);
				PreparedStatement pstmt = conn.prepareStatement("update users set password=? where username = ?");) {
			pstmt.setString(1, "updatedpassword");
			pstmt.setString(2, "harsh");

			int result = pstmt.executeUpdate();
			System.out.println(result);
		}
	}
}