package com.cdac.SpringBootMVCClient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMvcClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
