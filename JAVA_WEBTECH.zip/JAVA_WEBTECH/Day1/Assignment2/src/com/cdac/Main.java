package com.cdac;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/*
 * Create a Java Console Application that allows the User to create a new table with
columns in the database
1. Create Table
-> Accept the Table Name
->loop the below till Save is selected

a. Add column
->Accept the column name
-> show a list of standard types (VARCHAR, INT,FLOAT)
-> ask him to select an option this will be the datatype to be used for
the column

b. Set Primary Key
->Show all the columns above and ask him to select the column to act
as a primary key

c. Save
->this will result in saving the Table to the underlying database

2. Display Columns of a Table
-> Accept the name of the table and show Only the column names in that
table.
 */

public class Main {
	
	public static void createTable(Scanner sc, Connection conn) {
		System.out.println("Enter the name of the table that you wanna create");
		String tName = sc.nextLine();
		int ch = 0;
		
		List<String> columns = new ArrayList<>();
		List<String> datatypes = new ArrayList<>();
		String primaryKey = null;
		
		do {
			System.out.println("Enter your Choice:");
			System.out.println("1. Add Column");
			System.out.println("2. Set Primary Key");
			System.out.println("3. Save");
			ch = sc.nextInt();
			sc.nextLine();

			switch(ch) {
				case 1: {
					System.out.println("Enter name of column");
					String colname = sc.nextLine();
					System.out.println("Choose a DataType: 1.VARCHAR 2.INT 3.FLOAT");
					int dtype = sc.nextInt();
					sc.nextLine();
					
					String datatype;
					switch(dtype) {
						case 1: {
							System.out.println("Enter length for VARCHAR");
							int length = sc.nextInt();
							sc.nextLine();
							datatype = "VARCHAR("+length+")";
						} break;
						case 2: {
							datatype = "INT";
						} break;
						case 3: {
							datatype = "FLOAT";
						} break;
						default: {
							System.out.println("Invalid Choice. Try Again:");
						} continue;
					}
					
					columns.add(colname);
					datatypes.add(datatype);
					
				} break;
				case 2: {
					if (columns.isEmpty()) {
						System.out.println("No columns added yet.");
						break;
					}
					System.out.println("Choose column to make it a primary key");
					for (int i=0; i<columns.size(); i++) {
						System.out.println((i+1) + ". " + columns.get(i));
					}
					int pk = sc.nextInt();
					sc.nextLine();
					
					if (pk < 1 || pk > columns.size()) {
						System.out.println("Invalid Choice");
					} else {
						primaryKey = columns.get(pk-1);
					}
				} break;
				case 3: {
					if (columns.isEmpty()) {
						System.out.println("No columns to add. Cannot Save Table.");
						break;
					}
					saveTable(conn, tName, columns, datatypes, primaryKey);
				} break;
				default: {
					System.out.println("Wrong Choice");
				} break;
			}
		} while(ch != 3);
	}
	
	public static void saveTable(Connection conn, String tName, List<String> columns, List<String> datatypes, String primaryKey) {
		StringBuilder createTableQuery = new StringBuilder("create table ").append(tName).append(" (");
		for (int i=0; i<columns.size(); i++) {
			createTableQuery.append(columns.get(i)).append(" ").append(datatypes.get(i));
			if (i < columns.size()-1 || primaryKey != null) {
				createTableQuery.append(", ");
			}
		}
		if (primaryKey != null) {
			createTableQuery.append("primary key (").append(primaryKey).append(")");
		}
		createTableQuery.append(");");
		
		try (PreparedStatement psSave = conn.prepareStatement(createTableQuery.toString())){
			psSave.executeUpdate();
			System.out.println("Table "+tName+" created Successfully.");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) throws FileNotFoundException, IOException, SQLException {
		Map<String, String> dbCredentials = Credentials.getCredentials();
		String url = dbCredentials.get("connection_url");
		String user = dbCredentials.get("user");
		String password = dbCredentials.get("password");
		Connection conn = DriverManager.getConnection(url, user, password);
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Choose 1 to create a table & 2 to Display columns");
		int choice = sc.nextInt();
		sc.nextLine();
		if (choice == 1) {
			createTable(sc, conn);
		} else if (choice == 2) {
			displayColumns(sc, conn);
		} else {
			System.out.println("Wrong Choice");
		}
	}

	private static void displayColumns(Scanner sc, Connection conn) {
		System.out.println("Enter Table Name:");
		String tName = sc.nextLine();
		
		try (PreparedStatement psSelect = conn.prepareStatement("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = ? AND TABLE_SCHEMA = DATABASE()")){
			psSelect.setString(1, tName);
			try (ResultSet result = psSelect.executeQuery()){
				System.out.println("Columns in" + tName + " Table:");
				while (result.next()) {
					System.out.println(result.getString("COLUMN_NAME"));
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

}
