package com.cdac;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class Credentials {
	public static Map<String, String> getCredentials(){
		Map<String, String> map = new HashMap<>();
		
		Properties dbProps = new Properties();
		
		try {
			dbProps.load(new FileInputStream("DB.properties"));
			
			String url = dbProps.getProperty("conn.DBUrl");
			String user = dbProps.getProperty("conn.username");
			String pass = dbProps.getProperty("conn.password");
			
			map.put("connection_url", url);
			map.put("user", user);
			map.put("password", pass);
			
		} catch (IOException e) {
			System.out.println(e);
		}
		
		return map;
	}
}
