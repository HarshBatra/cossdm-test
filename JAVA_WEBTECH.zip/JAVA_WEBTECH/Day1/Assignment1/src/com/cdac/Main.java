package com.cdac;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Map;

public class Main {

	public static void main(String[] args) throws SQLException, FileNotFoundException, IOException {
		Map<String, String> dbCredentials = Credentials.getCredentials();
		
		DBQueries.registerUser(dbCredentials, "helloharsh22", "harsh1234", "Harsh Batra", "harshbat22@gmail.com", "New Delhi");
		DBQueries.registerUser(dbCredentials, "holaAmigo", "hola1234", "Hola Amigo", "holaamigo@gmail.com", "Pune");
		DBQueries.getUserByUsername(dbCredentials, "helloharsh22");
		DBQueries.getUsersByCity(dbCredentials, "Pune");
		DBQueries.updatePasswordByUsername(dbCredentials, "holaAmigo", "holahola");
	}

}
