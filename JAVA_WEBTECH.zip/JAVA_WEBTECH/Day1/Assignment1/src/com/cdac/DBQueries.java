package com.cdac;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

public class DBQueries {
//	1. Register a User
//	2. List All Users based on City
//	3. Update Password of a User
//	4. Display user information based on User Name
	
	public static void registerUser(Map<String,String> map, String username, String pass, String name, String email, String city) {
		String url = map.get("connection_url");
		String user = map.get("user");
		String password = map.get("password");
		
		try(Connection conn = DriverManager.getConnection(url, user, password);
				PreparedStatement psUpdate = conn.prepareStatement("insert into users values(?,?,?,?,?)")){
			psUpdate.setString(1, username);
			psUpdate.setString(2, pass);
			psUpdate.setString(3, name);
			psUpdate.setString(4, email);
			psUpdate.setString(5, city);
			int res = psUpdate.executeUpdate();
			System.out.println(res);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	public static void getUsersByCity(Map<String,String> map, String city) {
		String url = map.get("connection_url");
		String user = map.get("user");
		String password = map.get("password");
		
		try (Connection conn = DriverManager.getConnection(url, user, password);
				PreparedStatement psSelect = conn.prepareStatement("select * from users where city=?")){
			psSelect.setString(1, city);
			
			try (ResultSet result = psSelect.executeQuery()){
				while (result.next()) {
					System.out.print(result.getString(1) + " ");
					System.out.print(result.getString(2) + " ");
					System.out.print(result.getString(3) + " ");
					System.out.print(result.getString(4) + " ");
					System.out.print(result.getString(5) + " ");
					System.out.println();
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void updatePasswordByUsername(Map<String,String> map, String username, String pass) {
		String url = map.get("connection_url");
		String user = map.get("user");
		String password = map.get("password");
		
		try(Connection conn = DriverManager.getConnection(url, user, password);
				PreparedStatement psUpdate = conn.prepareStatement("update users set password=? where username=?")){
			psUpdate.setString(1, pass);
			psUpdate.setString(2, username);
			int res = psUpdate.executeUpdate();
			System.out.println(res);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void getUserByUsername(Map<String,String> map, String username) {
		String url = map.get("connection_url");
		String user = map.get("user");
		String password = map.get("password");
		
		try (Connection conn = DriverManager.getConnection(url, user, password);
				PreparedStatement psSelect = conn.prepareStatement("select * from users where username=?")){
			psSelect.setString(1, username);
			
			try (ResultSet res = psSelect.executeQuery()){
				while (res.next()) {
					System.out.print(res.getString(1) + " ");
					System.out.print(res.getString(2) + " ");
					System.out.print(res.getString(3) + " ");
					System.out.print(res.getString(4) + " ");
					System.out.print(res.getString(5) + " ");
					System.out.println();
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
