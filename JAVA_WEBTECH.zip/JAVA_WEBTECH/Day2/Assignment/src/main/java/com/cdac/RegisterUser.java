package com.cdac;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class RegisterUser extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter out = resp.getWriter();
		String username = req.getParameter("username");
		String password = req.getParameter("password");
		String name = req.getParameter("name");
		String email = req.getParameter("email");
		out.println("<html>");
		out.println("<body>");
		out.println("<table border=1>");
		out.println("<tr>");
		out.println("<th>Username</th>");
		out.println("<td>"+username+"</td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<th>Password</th>");
		out.println("<td>"+password+"</td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<th>Name</th>");
		out.println("<td>"+name+"</td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<th>Email</th>");
		out.println("<td>"+email+"</td>");
		out.println("</tr>");
		out.println("</table>");
		out.println("</body>");
		out.println("</html>");
	}
}
