package com.cdac;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class App 
{
    public static void main( String[] args )
    {
        Configuration hibernateCongiguration = new Configuration();
        
        hibernateCongiguration.configure("first.cfg.xml");
        
        try (SessionFactory hibernateFactory = hibernateCongiguration.buildSessionFactory();
        		Session hibernateSession = hibernateFactory.openSession();){
        	
        		// insert
        		store(hibernateSession);
        		
        		
        		// read
        		Users objUser = hibernateSession.get(Users.class, "user1");
        		
        		System.out.println(objUser.getName());
        		System.out.println(objUser.getEmail());
        		System.out.println(objUser.getPassword());
        		System.out.println(objUser.getUserName());
        		
        } catch (HibernateException e) {
			e.printStackTrace();
		}
    }
    
    private static void store(Session hibernateSession) {
    	Users objUser = new Users("user4","user4","user4","user4");
    	
    	Transaction tx = hibernateSession.beginTransaction();
    	
    	hibernateSession.persist(objUser);
    	
    	tx.commit();
    }
}
