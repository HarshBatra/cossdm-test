package com.servlet;

import java.io.IOException;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.hibernate.entity.Users;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.ServletException;

@WebServlet("/Authenticate")
public class Authenticate extends jakarta.servlet.http.HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userName = request.getParameter("userName");
		String password = request.getParameter("password");
		
		ServletContext application = getServletContext();
		
		SessionFactory hibFactory = (SessionFactory) application.getAttribute("hibFactory");
		
		try (Session hibSession = hibFactory.openSession()){
			Users objUser = hibSession.get(Users.class, userName);
			
			if (objUser.getPassword().equals(password)) {
				response.sendRedirect("category.jsp");
				return;
			}
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		
		response.sendRedirect("login.html");
	}

}
