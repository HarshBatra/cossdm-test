package com.cdac;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class App 
{
    public static void main( String[] args )
    {
       Configuration hibConfig = new Configuration();
       
       try {
    	   
    	   Properties configProps = new Properties();
    	   
    	   configProps.load(new FileInputStream("application.properties"));
    	   
    	   hibConfig.addProperties(configProps);
    	   
    	   hibConfig.addAnnotatedClass(Users.class);
    	   
    	   try (SessionFactory hibFactory = hibConfig.buildSessionFactory();
        		   Session hibSession = hibFactory.openSession();){
        	   
        	   Users objUser = hibSession.get(Users.class, "user1");
        	   System.out.println(objUser.getName());
        	   System.out.println(objUser.getEmail());
        	   System.out.println(objUser.getPassword());
        	   
           } catch (HibernateException e) {
        	   e.printStackTrace();
           }
    	   
       } catch (FileNotFoundException e){
    	   e.printStackTrace();
       } catch (IOException e) {
		e.printStackTrace();
	}       
       
    }
}
