package com.auth;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Servlet implementation class Authenticate
 */
@WebServlet("/Authenticate")
public class Authenticate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection conn;
	PreparedStatement ps;

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		// TODO Auto-generated method stub
		ServletContext application = getServletContext();
		try {
			conn = (Connection) application.getAttribute("connObj");
			ps = conn.prepareStatement("select * from users where username=? and password=?");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error inside init method of Authenticate " + e);
		} 
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String name = request.getParameter("username");
		String pass = request.getParameter("password");

		PrintWriter out = response.getWriter();

		try {
			ps.setString(1, name);
			ps.setString(2, pass);
			
			try (ResultSet res = ps.executeQuery();) {
				if (res.next()) {
					HttpSession session = request.getSession(true);
					session.setAttribute("username", name);
					response.sendRedirect("Category.jsp");
				} else {
					out.print("Arpit Sarap");
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error inside doPost method of Authenticate " + e);
		}
	}

}
