package com.auth;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;

@WebServlet(urlPatterns = "/InitConn",loadOnStartup = 1)
public class InitConn extends HttpServlet {
	
	Connection conn;
	
	private static final long serialVersionUID = 1L;
	
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		System.out.println("Initializing database connection...");
		ServletContext application = getServletContext();
		try {
			Class.forName(application.getInitParameter("jdbc_class"));
			conn = DriverManager.getConnection(application.getInitParameter("DBUrl"),
					application.getInitParameter("user"), application.getInitParameter("password"));
			application.setAttribute("connObj", conn);
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void destroy() {
		try {
			if (conn != null) {
				conn.close();
			}
		} catch (SQLException e) {
			System.out.println("Error closing the database connection: " + e.getMessage());
		}
	}

}
