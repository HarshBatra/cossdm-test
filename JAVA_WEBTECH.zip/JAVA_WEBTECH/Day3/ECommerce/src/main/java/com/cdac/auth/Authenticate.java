package com.cdac.auth;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet("/Authenticate")
public class Authenticate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	Connection conn;
	PreparedStatement psAuthenticate;
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		
		try {
			ServletContext context = getServletContext();
			
			String dbUrl = context.getInitParameter("dbUrl");
			String dbDriver = context.getInitParameter("dbDriver");
			String dbUser = context.getInitParameter("dbUser");
			String dbPassword = context.getInitParameter("dbPassword");
			
			Class.forName(dbDriver);
			conn = DriverManager.getConnection(dbUrl, dbUser, dbPassword);
			
			psAuthenticate = conn.prepareStatement("select * from users where username=? and password=?");
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
			throw new ServletException("DB Connection Issues", e);
		}
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		
		PrintWriter out = response.getWriter();
		
		if (username == null || password == null) throw new ServletException("Input Parameter Issues");
		
		try {
			psAuthenticate.setString(1, username);
			psAuthenticate.setString(2, password);
			try (ResultSet result = psAuthenticate.executeQuery()){
				if (result.next()) {
					String user = result.getString("username");
					if (user.equals("admin")) {
						response.sendRedirect("admin/administration.html");
					} else {
						response.sendRedirect("Category");
						
					}
				}
				else out.println("Authentication Failure");
			} 
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void destroy() {
		try {
			if (psAuthenticate != null) psAuthenticate.close();
			if (conn != null) conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
