package com.cdac.admin;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/AddProduct")
public class AddProduct extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	Connection conn;
	PreparedStatement psProductUpdate;
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		
		try {
			ServletContext context = getServletContext();
			String dbDriver = context.getInitParameter("dbDriver");
			String dbUrl = context.getInitParameter("dbUrl");
			String dbUser = context.getInitParameter("dbUser");
			String dbPassword = context.getInitParameter("dbPassword");
			
			Class.forName(dbDriver);
			conn = DriverManager.getConnection(dbUrl, dbUser, dbPassword);
			psProductUpdate = conn.prepareStatement("insert into products(product_id, category_id, product_name, product_desc, product_price, product_imgurl) values(?,?,?,?,?,?)");
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
			throw new ServletException("DB Connection Issues", e);
		}
	}
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		
		String productIdString = request.getParameter("productId");
	    int productId = 0; // Default value to prevent uninitialized usage

	    // Input validation
	    if (productIdString == null || productIdString.trim().isEmpty()) {
	        out.println("Error: Product ID is required and cannot be empty.");
	        return;
	    }

	    try {
	        productId = Integer.parseInt(productIdString); // Safe parsing
	    } catch (NumberFormatException e) {
	        out.println("Error: Product ID must be a valid number.");
	        return;
	    }
		
		String categoryIdString = request.getParameter("categoryId");
	    int categoryId = 0; // Default value to prevent uninitialized usage

	    // Input validation
	    if (categoryIdString == null || categoryIdString.trim().isEmpty()) {
	        out.println("Error: Category ID is required and cannot be empty.");
	        return;
	    }

	    try {
	        categoryId = Integer.parseInt(categoryIdString); // Safe parsing
	    } catch (NumberFormatException e) {
	        out.println("Error: Category ID must be a valid number.");
	        return;
	    }
	    
		String productName = request.getParameter("productName");
		String productDesc = request.getParameter("productDesc");
		String productPrice = request.getParameter("productPrice");
		String productImgUrl = request.getParameter("productImgUrl");
		
		try {
			psProductUpdate.setInt(1, productId);
			psProductUpdate.setInt(2, categoryId);
			psProductUpdate.setString(3, productName);
			psProductUpdate.setString(4, productDesc);
			psProductUpdate.setString(5, productPrice);
			psProductUpdate.setString(6, productImgUrl);
			
			int result = psProductUpdate.executeUpdate();
			System.out.println(result);
			
			if (result == 0) {
				out.println("Product Could Not Be Added");
			} else {
				response.sendRedirect("admin/administration.html");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void destroy() {
		try {
			if (psProductUpdate != null) psProductUpdate.close();
			if (conn != null) conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
