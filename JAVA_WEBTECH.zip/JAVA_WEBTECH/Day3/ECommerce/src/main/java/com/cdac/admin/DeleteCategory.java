package com.cdac.admin;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

@WebServlet("/DeleteCategory")
public class DeleteCategory extends HttpServlet {
    private static final long serialVersionUID = 1L;

    Connection conn;
    PreparedStatement psDeleteProducts;
    PreparedStatement psDeleteCategory;

    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);

        try {
            ServletContext context = getServletContext();
            String dbDriver = context.getInitParameter("dbDriver");
            String dbUrl = context.getInitParameter("dbUrl");
            String dbUser = context.getInitParameter("dbUser");
            String dbPassword = context.getInitParameter("dbPassword");

            Class.forName(dbDriver);
            conn = DriverManager.getConnection(dbUrl, dbUser, dbPassword);
            
            psDeleteProducts = conn.prepareStatement("DELETE FROM products WHERE category_id = ?");
            psDeleteCategory = conn.prepareStatement("DELETE FROM category WHERE category_id = ?");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            throw new ServletException("DB Connection Issues", e);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        response.setContentType("text/html");

        String categoryIdStr = request.getParameter("categoryId");
        if (categoryIdStr == null || categoryIdStr.trim().isEmpty()) {
            out.println("Error: Category ID is required.");
            return;
        }

        try {
            int categoryId = Integer.parseInt(categoryIdStr);

            conn.setAutoCommit(false);

            psDeleteProducts.setInt(1, categoryId);
            psDeleteProducts.executeUpdate();

            psDeleteCategory.setInt(1, categoryId);
            int result = psDeleteCategory.executeUpdate();

            if (result > 0) {
                conn.commit();
                response.sendRedirect("admin/administration.html");
            } else {
                conn.rollback();
                out.println("<h3>Category Could Not Be Deleted. Please Try Again.</h3>");
            }
        } catch (NumberFormatException e) {
            out.println("Error: Invalid Category ID.");
        } catch (SQLException e) {
            e.printStackTrace();
            try {
                conn.rollback();
            } catch (SQLException e2) {
                e2.printStackTrace();
            }
            out.println("Database Error: " + e.getMessage());
        } finally {
            try {
                conn.setAutoCommit(true);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void destroy() {
        try {
            if (psDeleteProducts != null) psDeleteProducts.close();
            if (psDeleteCategory != null) psDeleteCategory.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
