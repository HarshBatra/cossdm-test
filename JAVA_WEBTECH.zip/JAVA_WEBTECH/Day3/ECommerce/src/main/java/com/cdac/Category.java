package com.cdac;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet("/Category")
public class Category extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	Connection conn;
	PreparedStatement psCategory;
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		
		try {
			ServletContext context = getServletContext();
			
			String dbUrl = context.getInitParameter("dbUrl");
			String dbDriver = context.getInitParameter("dbDriver");
			String dbUser = context.getInitParameter("dbUser");
			String dbPassword = context.getInitParameter("dbPassword");
			
			Class.forName(dbDriver);
			conn = DriverManager.getConnection(dbUrl, dbUser, dbPassword);
			psCategory = conn.prepareStatement("select * from category");
		}catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
			throw new ServletException("DB Connection Issues", e);
		}
	}
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		
			try (ResultSet result = psCategory.executeQuery()) {
				out.println("<html>");
				out.println("<body>");
				out.println("<table border=1>");
				out.println("<tr>");
				out.println("<th>Category ID</th>");
				out.println("<th>Category Name</th>");
				out.println("<th>Category Description</th>");
				out.println("<th>Category ImgUrl</th>");
				out.println("</tr>");
				while(result.next()) {
					out.println("<tr>");
					out.println("<td>"+result.getString("category_id")+"</td>");
					out.println("<td><a href='Products?categoryId="+result.getString("category_id")+"'>"+result.getString("category_name")+"</td>");
					out.println("<td>"+result.getString("category_desc")+"</a></td>");
					out.println("<td><img src='Images/"+result.getString("category_imgurl")+"' height='50px' width='50px'/></td>");
					out.println("</tr>");
				}
				out.println("</table>");
				out.println("<body>");
				out.println("</html>");
			} catch (SQLException e) {
				e.printStackTrace();
			}
	}
	
	@Override
	public void destroy() {
		try {
			if (psCategory != null) psCategory.close();
			if (conn != null) conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
