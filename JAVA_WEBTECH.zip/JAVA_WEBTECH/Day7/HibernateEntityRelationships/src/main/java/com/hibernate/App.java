package com.hibernate;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.Properties;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import com.hibernate.entity.Category;
import com.hibernate.entity.ProductId;
import com.hibernate.entity.Products;

public class App {
	public static void main(String[] args) {
		Configuration hibConfig = new Configuration();
		
		try { 
			Properties hibProps = new Properties();
			hibProps.load(new FileInputStream("application.properties"));
			
			hibConfig.addProperties(hibProps);
			
			hibConfig.addAnnotatedClass(Products.class);
			hibConfig.addAnnotatedClass(Category.class);
			
			try (SessionFactory hibFactory = hibConfig.buildSessionFactory();
					Session hibSession = hibFactory.openSession()){
				
//				ProductId pid = new ProductId(1,2);
//				Products objProduct = hibSession.get(Products.class, pid);
//				
//				System.out.println(objProduct.getPid().getCategoryId());
//				System.out.println(objProduct.getPid().getProductId());
//				System.out.println(objProduct.getProductName());
//				System.out.println(objProduct.getProductDesc());
//				System.out.println(objProduct.getProduuctPrice());
//				System.out.println(objProduct.getProductImgUrl());
				
				
				
//				Query<Category> queryCat = hibSession.createQuery("select object(category) from Category category where category.categoryId=:cid", Category.class);
//				queryCat.setParameter("cid", 1);
				
//				Query<Category> queryCat = hibSession.createNamedQuery("allCategories", Category.class);
//				List<Category> listCategory = queryCat.getResultList();
//				
//				listCategory.forEach((objCat)->{
//					System.out.println(objCat.getCategoryId());
//					System.out.println(objCat.getCategoryName());
//					System.out.println(objCat.getCategoryDesc());
//					System.out.println(objCat.getCategoryImagUrl());
//				});
				
				
				
				
				Query<Products> productsByCategory = hibSession.createNamedQuery("productsByCategory", Products.class);
				
				productsByCategory.setParameter("cid", 1);
				List<Products> list = productsByCategory.getResultList();
				list.forEach((prod)->{
					System.out.println(prod.getPid().getCategoryId());
					System.out.println(prod.getPid().getProductId());
					System.out.println(prod.getProductName());
					System.out.println(prod.getProductDesc());
				});
				
			} catch (HibernateException e) {
				e.printStackTrace();
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
}
