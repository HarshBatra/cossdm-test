package com.hibernate.entity;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Table(name="products")
@NamedQueries({
	@NamedQuery(name="productsByCategoryId", query="select object(product) from Products product where product.pid.categoryId=:cid"),
	@NamedQuery(name="productsById", query="select object(product) from Products product where product.pid.categoryId=:cid and product.pid.productId=:prodId"),
})
public class Products {
	@EmbeddedId
	ProductId pid;
	
	@Column(name="product_name")
	String productName;
	@Column(name="product_desc")
	String productDesc;
	@Column(name="product_price")
	float produuctPrice;
	@Column(name="product_imgurl")
	String productImgUrl;
	
	public Products() {}
	
	public Products(ProductId pid, String productName, String productDesc, float produuctPrice, String productImgUrl) {
		super();
		this.pid = pid;
		this.productName = productName;
		this.productDesc = productDesc;
		this.produuctPrice = produuctPrice;
		this.productImgUrl = productImgUrl;
	}

	public ProductId getPid() {
		return pid;
	}

	public void setPid(ProductId pid) {
		this.pid = pid;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductDesc() {
		return productDesc;
	}

	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}

	public float getProduuctPrice() {
		return produuctPrice;
	}

	public void setProduuctPrice(float produuctPrice) {
		this.produuctPrice = produuctPrice;
	}

	public String getProductImgUrl() {
		return productImgUrl;
	}

	public void setProductImgUrl(String productImgUrl) {
		this.productImgUrl = productImgUrl;
	}
	
	
	
}
