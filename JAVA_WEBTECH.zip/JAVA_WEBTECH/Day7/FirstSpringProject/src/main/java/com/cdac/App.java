package com.cdac;

import org.springframework.beans.BeansException;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
        try (ClassPathXmlApplicationContext appContext = new ClassPathXmlApplicationContext("spring-beans.xml")) {
			Users objUser = (Users) appContext.getBean("objUser");
			
			System.out.println(objUser.getUsername());
			System.out.println(objUser.getPassword());
		} catch (BeansException e) {
			e.printStackTrace();
		}
    }
}
