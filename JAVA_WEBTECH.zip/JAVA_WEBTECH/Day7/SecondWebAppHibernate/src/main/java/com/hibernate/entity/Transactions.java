package com.hibernate.entity;

import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="transactions")
public class Transactions {
	@Id
	@Column(name="transaction_id")
	int TransactionId;
	
	@Column(name="amount")
	float amount;
	
	@Column(name="card_no")
	int cardNo;
	
	@Column(name="transaction_date")
	Date txDate;
	
	@Column(name="status")
	String status;
	
	public Transactions() {}

	public Transactions(int transactionId, float amount, int cardNo, Date txDate, String status) {
		super();
		TransactionId = transactionId;
		this.amount = amount;
		this.cardNo = cardNo;
		this.txDate = txDate;
		this.status = status;
	}

	public int getTransactionId() {
		return TransactionId;
	}

	public void setTransactionId(int transactionId) {
		TransactionId = transactionId;
	}

	public float getAmount() {
		return amount;
	}

	public void setAmount(float amount) {
		this.amount = amount;
	}

	public int getCardNo() {
		return cardNo;
	}

	public void setCardNo(int cardNo) {
		this.cardNo = cardNo;
	}

	public Date getTxDate() {
		return txDate;
	}

	public void setTxDate(Date txDate) {
		this.txDate = txDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	
}
