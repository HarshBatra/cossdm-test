package com.hibernate;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;

import java.util.Properties;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.hibernate.entity.Cards;
import com.hibernate.entity.Transactions;

@WebServlet(loadOnStartup = 1, urlPatterns = { "/InitializeHibernate" })
public class InitializeHibernate extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		
		Configuration hibConfig = new Configuration();
		
		Properties hibProps = new Properties();
		
		hibProps.setProperty("hibernate.connection.driver_class", "com.mysql.cj.jdbc.Driver");
		hibProps.setProperty("hibernate.connection.url", "jdbc:mysql://localhost:3306/ecommerce");
		hibProps.setProperty("hibernate.connection.username", "root");
		hibProps.setProperty("hibernate.connection.password", "harsh2222");
		hibProps.setProperty("hibernate.dialect", "org.hibernate.dialect.MySQL8Dialect");
		hibProps.setProperty("hibernate.show_sql", "true");
		
		hibConfig.addProperties(hibProps);
		
		hibConfig.addAnnotatedClass(Cards.class);
		hibConfig.addAnnotatedClass(Transactions.class);
		
		
		SessionFactory hibFactory = hibConfig.buildSessionFactory();
		getServletContext().setAttribute("hibFactory", hibFactory);
	}

}
