package com.hibernate.entity;

import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="cards")
public class Cards {
	@Id
	@Column(name="card_no")
	int cardNo;
	
	@Column(name="expiry_date")
	Date expiryDate;
	
	@Column(name="balance")
	float balance;
	
	@Column(name="username")
	String username;
	
	public Cards() {}

	public Cards(int cardNo, Date expiryDate, float balance, String username) {
		super();
		this.cardNo = cardNo;
		this.expiryDate = expiryDate;
		this.balance = balance;
		this.username = username;
	}

	public int getCardNo() {
		return cardNo;
	}

	public void setCardNo(int cardNo) {
		this.cardNo = cardNo;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	public float getBalance() {
		return balance;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}
	
	
}
