package com.cdac.cart;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;

@WebServlet("/ListCart")
public class ListCart extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		if (session == null) {
			response.sendRedirect("auth/login.html");
			return;
		} else {
			String username = (String) session.getAttribute("username");
			if (username.equals("admin")) {
				response.sendRedirect("admin/administration.html");
				return;
			}
		}
		
		String username = (String) session.getAttribute("username");
		
		PrintWriter out = response.getWriter();
		
		out.println("<html><body>");
		out.println("<b>" + username + "'s Cart: </b>");
		
		Cart objCart = (Cart) session.getAttribute("cart");
		
		if (objCart==null) {
			out.println("Cart is Empty");
		} else {
			Iterator<CartItem> iter = objCart.listCart();
			double total = 0.0;
			
			out.println("<table border=1><tr><th>Category ID</th><th>Product ID</th><th>Price</th></tr>");

			while (iter.hasNext()) {
				CartItem cartItem = iter.next();
				out.println("<tr><td>" + cartItem.getCategoryId() + "</td>");
				out.println("<td>" + cartItem.getProductId() + "</td>");
				out.println("<td>" + cartItem.getProductPrice() + "</td>");
				total += cartItem.getProductPrice();
			}
			out.println("</table>");			
			out.println("Total: <b>" + total + "</b></br>");
			out.println("<a href='user/addcard.html'>Add New Card</a></br>");
			out.println("<a href='Checkout'>Checkout</a></br>");
			out.println("<a href='Category'>Continue Shopping</a></br>");
			out.println("<a href='Logout'>Logout</a></br>");
		}
		
		out.println("</body></html>");
	}

}
