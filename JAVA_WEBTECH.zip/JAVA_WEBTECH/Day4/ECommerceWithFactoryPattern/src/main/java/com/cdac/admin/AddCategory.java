package com.cdac.admin;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/AddCategory")
public class AddCategory extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	Connection conn;
	PreparedStatement psCategoryUpdate;
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		
		try {
			ServletContext context = getServletContext();
			String dbDriver = context.getInitParameter("dbDriver");
			String dbUrl = context.getInitParameter("dbUrl");
			String dbUser = context.getInitParameter("dbUser");
			String dbPassword = context.getInitParameter("dbPassword");
			
			Class.forName(dbDriver);
			conn = DriverManager.getConnection(dbUrl, dbUser, dbPassword);
			psCategoryUpdate = conn.prepareStatement("insert into category(category_id, category_name, category_desc, category_imgurl) values(?,?,?,?)");
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
			throw new ServletException("DB Connection Issues", e);
		}
	}
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession(false);
		if (session == null) {
			response.sendRedirect("auth/login.html");
			return;
		} else {
			String username = (String) session.getAttribute("username");
			if (!username.equals("admin")) {
				response.sendRedirect("Category");
				return;
			}
		}
		
		PrintWriter out = response.getWriter();
		
		String categoryIdString = request.getParameter("categoryId");
	    int categoryId = 0; // Default value to prevent uninitialized usage

	    // Input validation
	    if (categoryIdString == null || categoryIdString.trim().isEmpty()) {
	        out.println("Error: Category ID is required and cannot be empty.");
	        return;
	    }

	    try {
	        categoryId = Integer.parseInt(categoryIdString); // Safe parsing
	    } catch (NumberFormatException e) {
	        out.println("Error: Category ID must be a valid number.");
	        return;
	    }
	    
		String categoryName = request.getParameter("categoryName");
		String categoryDesc = request.getParameter("categoryDesc");
		String categoryImgUrl = request.getParameter("categoryImgUrl");
		
		try {
			psCategoryUpdate.setInt(1, categoryId);
			psCategoryUpdate.setString(2, categoryName);
			psCategoryUpdate.setString(3, categoryDesc);
			psCategoryUpdate.setString(4, categoryImgUrl);
			
			int result = psCategoryUpdate.executeUpdate();
			
			if (result == 0) {
				out.println("Category Could Not Be Added");
			} else {
				response.sendRedirect("admin/administration.html");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}
	
	@Override
	public void destroy() {
		try {
			if (psCategoryUpdate != null) psCategoryUpdate.close();
			if (conn != null) conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
