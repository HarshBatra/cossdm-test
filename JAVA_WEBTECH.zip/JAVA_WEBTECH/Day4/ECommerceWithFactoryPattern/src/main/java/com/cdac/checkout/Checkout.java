package com.cdac.checkout;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;

import com.cdac.cart.Cart;
import com.cdac.cart.CartItem;

@WebServlet("/Checkout")
public class Checkout extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	Connection conn;
	PreparedStatement psSelectAllCards;
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		
		try {
			ServletContext context = getServletContext();
			
			String dbUrl = context.getInitParameter("dbUrl");
			String dbDriver = context.getInitParameter("dbDriver");
			String dbUser = context.getInitParameter("dbUser");
			String dbPassword = context.getInitParameter("dbPassword");
			
			Class.forName(dbDriver);
			conn = DriverManager.getConnection(dbUrl, dbUser, dbPassword);
			
			psSelectAllCards = conn.prepareStatement("select * from cards where username=?");
		}catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
			throw new ServletException("DB Connection Issues", e);
		}
	}
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		if (session == null) {
			response.sendRedirect("auth/login.html");
			return;
		} else {
			String username = (String) session.getAttribute("username");
			if (username.equals("admin")) {
				response.sendRedirect("admin/administration.html");
				return;
			}
		}
		
		PrintWriter out = response.getWriter();
		
		String username = (String) session.getAttribute("username");
		
		try {
			psSelectAllCards.setString(1, username);
			
	        try(ResultSet res = psSelectAllCards.executeQuery()){
	        	
				out.println("<html><body>");
				out.println("<h3>Checkout</h3>");
				
				Cart objCart = (Cart) session.getAttribute("cart");
				if (objCart==null) {
					out.println("Cart is Empty. Can't Checkout");
					return;
				} else {
					Iterator<CartItem> iter = objCart.listCart();
					double total = 0.0;
					while (iter.hasNext()) {
						CartItem cartItem = iter.next();
						total += cartItem.getProductPrice();
					}
					out.println("Cart Total: <b>"+ total +"</b><br>");
				}
				out.println("<h3>"+username+"'s Cards</h3>");
				
				out.println("<form action='Payment' method='post'>");
				 out.println("<label for='cardNo'>Select Card to Pay:</label>");
		         out.println("<select id='cardNo' name='cardNo'>");
		
		         while (res.next()) {
		             int cardNo = res.getInt("card_no");
		             out.println("<option value='" + cardNo + "'>" + cardNo + "</option>");
		         }
		
		         out.println("</select><br><br>");
		         out.println("<input type='submit' value='Pay Now'/>");
		         out.println("</form></body></html>");
				
	        } 
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void destroy() {
		try {
			if (psSelectAllCards != null) psSelectAllCards.close();
			if (conn != null) conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
