package com.cdac.admin;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;


@WebServlet("/FetchCategoriesToDelete")
public class FetchCategoriesToDelete extends HttpServlet {
    private static final long serialVersionUID = 1L;

    Connection conn;
    PreparedStatement psFetchCategories;

    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);

        try {
            ServletContext context = getServletContext();
            String dbDriver = context.getInitParameter("dbDriver");
            String dbUrl = context.getInitParameter("dbUrl");
            String dbUser = context.getInitParameter("dbUser");
            String dbPassword = context.getInitParameter("dbPassword");

            Class.forName(dbDriver);
            conn = DriverManager.getConnection(dbUrl, dbUser, dbPassword);
            psFetchCategories = conn.prepareStatement("SELECT category_id, category_name FROM category");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            throw new ServletException("DB Connection Issues", e);
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	
    	HttpSession session = request.getSession(false);
		if (session == null) {
			response.sendRedirect("auth/login.html");
			return;
		} else {
			String username = (String) session.getAttribute("username");
			if (!username.equals("admin")) {
				response.sendRedirect("Category");
				return;
			}
		}
    	
        PrintWriter out = response.getWriter();
        response.setContentType("text/html");

        try (ResultSet res = psFetchCategories.executeQuery()) {
            out.println("<html><head><title>Delete Category</title></head><body>");
            out.println("<h1>Delete a Category</h1>");
            out.println("<form action='DeleteCategory' method='post'>");

            out.println("<label for='categoryId'>Select Category to Delete:</label>");
            out.println("<select id='categoryId' name='categoryId'>");

            while (res.next()) {
                int id = res.getInt("category_id");
                String name = res.getString("category_name");
                out.println("<option value='" + id + "'>" + name + "</option>");
            }

            out.println("</select><br><br>");
            out.println("<input type='submit' value='Delete Category' />");
            out.println("</form><br>");
			out.println("<a href='Logout'>LogOut</a>");
            out.println("</body></html>");
        } catch (SQLException e) {
            e.printStackTrace();
            out.println("Error Fetching Categories: " + e.getMessage());
        }
    }

    @Override
    public void destroy() {
        try {
            if (psFetchCategories != null) psFetchCategories.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
