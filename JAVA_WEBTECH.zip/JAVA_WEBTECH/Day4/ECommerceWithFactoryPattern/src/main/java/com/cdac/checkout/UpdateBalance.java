package com.cdac.checkout;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;


@WebServlet("/UpdateBalance")
public class UpdateBalance extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	Connection conn;
	PreparedStatement psUpdateBalance;
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		
		try {
			ServletContext context = getServletContext();
			
			String dbUrl = context.getInitParameter("dbUrl");
			String dbDriver = context.getInitParameter("dbDriver");
			String dbUser = context.getInitParameter("dbUser");
			String dbPassword = context.getInitParameter("dbPassword");
			
			Class.forName(dbDriver);
			conn = DriverManager.getConnection(dbUrl, dbUser, dbPassword);
			
			psUpdateBalance = conn.prepareStatement("update cards set balance=? where card_no=?");
		}catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
			throw new ServletException("DB Connection Issues", e);
		}
	}
 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		if (session == null) {
			response.sendRedirect("auth/login.html");
			return;
		} else {
			String username = (String) session.getAttribute("username");
			if (username.equals("admin")) {
				response.sendRedirect("admin/administration.html");
				return;
			}
		}
		
		PrintWriter out = response.getWriter();
				
		String cardNoStr = request.getParameter("cardNo");
		int cardNo = 0;
		if (cardNoStr == null || cardNoStr.trim().isEmpty()) {
	        out.println("Error: Card No is required and cannot be empty.");
	        return;
	    }
	    try {
	    	cardNo = Integer.parseInt(cardNoStr);
	    } catch (NumberFormatException e) {
	        out.println("Error: Card No must be a valid number.");
	        return;
	    }
	    
	    String balanceStr = request.getParameter("balance");
		float balance = 0;
		if (balanceStr == null || balanceStr.trim().isEmpty()) {
	        out.println("Error: Card No is required and cannot be empty.");
	        return;
	    }
	    try {
	    	balance = Float.parseFloat(balanceStr);
	    } catch (NumberFormatException e) {
	        out.println("Error: Card No must be a valid number.");
	        return;
	    }
		
		try {
			psUpdateBalance.setFloat(1, balance);
			psUpdateBalance.setInt(1, cardNo);
			
	        psUpdateBalance.executeUpdate();
	        
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void destroy() {
		try {
			if (psUpdateBalance != null) psUpdateBalance.close();
			if (conn != null) conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
