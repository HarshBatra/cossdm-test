package com.cdac.checkout;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.Iterator;

import com.cdac.cart.Cart;
import com.cdac.cart.CartItem;

@WebServlet("/Payment")
public class Payment extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	Connection conn;
	PreparedStatement psSelectAllCards;
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		
		try {
			ServletContext context = getServletContext();
			
			String dbUrl = context.getInitParameter("dbUrl");
			String dbDriver = context.getInitParameter("dbDriver");
			String dbUser = context.getInitParameter("dbUser");
			String dbPassword = context.getInitParameter("dbPassword");
			
			Class.forName(dbDriver);
			conn = DriverManager.getConnection(dbUrl, dbUser, dbPassword);
			
			psSelectAllCards = conn.prepareStatement("select * from cards where card_no=?");
		}catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
			throw new ServletException("DB Connection Issues", e);
		}
	}
 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		if (session == null) {
			response.sendRedirect("auth/login.html");
			return;
		} else {
			String username = (String) session.getAttribute("username");
			if (username.equals("admin")) {
				response.sendRedirect("admin/administration.html");
				return;
			}
		}
		
		PrintWriter out = response.getWriter();
		out.println("<html><body>");
		
		String username = (String) session.getAttribute("username");
				
		String cardNoStr = request.getParameter("cardNo");
		int cardNo = 0;
		if (cardNoStr == null || cardNoStr.trim().isEmpty()) {
	        out.println("Error: Card No is required and cannot be empty.");
	        return;
	    }
	    try {
	    	cardNo = Integer.parseInt(cardNoStr);
	    } catch (NumberFormatException e) {
	        out.println("Error: Card No must be a valid number.");
	        return;
	    }
		
		try {
			psSelectAllCards.setInt(1, cardNo);
			
	        try(ResultSet res = psSelectAllCards.executeQuery()){
	        	
				out.println("<h3>Payment Status</h3>");
				
				Cart objCart = (Cart) session.getAttribute("cart");
				double total = 0.0;
				if (objCart==null) {
					out.println("Cart is Empty. Can't Checkout");
					return;
				} else {
					Iterator<CartItem> iter = objCart.listCart();
					out.println("<table border=1><tr><th>Category ID</th><th>Product ID</th><th>Price</th></tr>");
					while (iter.hasNext()) {
						CartItem cartItem = iter.next();
						total += cartItem.getProductPrice();
					}
				}	
		
				while (res.next()) {
					float balance = res.getFloat("balance");
					Date expiryDate = res.getDate("expiry_date");
					Date today = new Date();
					if (balance >= total && expiryDate.after(today)) {
						
						balance -= total;
						
						request.setAttribute("cardNo", cardNo);
						request.setAttribute("balance", balance);
						request.setAttribute("date", today);
						request.setAttribute("amount", total);
						request.setAttribute("username", username);
					    request.getRequestDispatcher("UpdateBalance").forward(request, response);
					    request.getRequestDispatcher("UpdateTransaction").forward(request, response);
						
						out.println("<h1>Payment Succesfull! Updated Balance: " + balance + " </h1>");
					} else if (balance < total) {
						out.println("<h1> Insufficient Balance in card. You are Gareeb! </h1>");
					} else {
						out.println("<h1> Card Date Expired. </h1>");
					}
				}
				out.println("</body></html>");
				
	        } 
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void destroy() {
		try {
			if (psSelectAllCards != null) psSelectAllCards.close();
			if (conn != null) conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
