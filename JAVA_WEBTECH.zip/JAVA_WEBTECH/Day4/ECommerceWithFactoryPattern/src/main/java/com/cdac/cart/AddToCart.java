package com.cdac.cart;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet("/AddToCart")
public class AddToCart extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		if (session == null) {
			response.sendRedirect("auth/login.html");
			return;
		} else {
			String username = (String) session.getAttribute("username");
			if (username.equals("admin")) {
				response.sendRedirect("admin/administration.html");
				return;
			}
		}
		

		String categoryIdStr = request.getParameter("categoryId");
		int categoryId = Integer.parseInt(categoryIdStr);
		String productIdStr = request.getParameter("productId");
		int productId = Integer.parseInt(productIdStr);
		String productPriceStr = request.getParameter("productPrice");
		int productPrice = Integer.parseInt(productPriceStr);
		
		CartItem objItem = new CartItem(categoryId, productId, productPrice);
		
		Cart objCart = (Cart) session.getAttribute("cart");
		
		if (objCart == null) {
			objCart = CartFactory.getInstance(getServletContext());
			session.setAttribute("cart", objCart);
		}
		
		objCart.addItem(objItem);
		
		response.sendRedirect("ListCart");
	}

}
