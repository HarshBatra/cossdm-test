package com.cdac.checkout;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/AddCard")
public class AddCard extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	Connection conn;
	PreparedStatement psAddCard;
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		
		try {
			ServletContext context = getServletContext();
			
			String dbUrl = context.getInitParameter("dbUrl");
			String dbDriver = context.getInitParameter("dbDriver");
			String dbUser = context.getInitParameter("dbUser");
			String dbPassword = context.getInitParameter("dbPassword");
			
			Class.forName(dbDriver);
			conn = DriverManager.getConnection(dbUrl, dbUser, dbPassword);
			
			psAddCard = conn.prepareStatement("insert into cards(username, card_no, expiry_date, balance) values (?,?,?,?)");
		}catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
			throw new ServletException("DB Connection Issues", e);
		}
	}
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		if (session == null) {
			response.sendRedirect("auth/login.html");
			return;
		} else {
			String username = (String) session.getAttribute("username");
			if (username.equals("admin")) {
				response.sendRedirect("admin/administration.html");
				return;
			}
		}
		
		PrintWriter out = response.getWriter();
		
		String username = (String) session.getAttribute("username");
		
		String cardNoStr = request.getParameter("cardNo");
		String expiryDateStr = request.getParameter("expiryDate");
		String balanceStr = request.getParameter("balance");
		
		Date expiryDate = null;
		if (expiryDateStr == null || expiryDateStr.trim().isEmpty()) {
		    out.println("Error: Expiry Date is required.");
		    return;
		}

		try {
		    expiryDate = Date.valueOf(expiryDateStr);
		} catch (IllegalArgumentException e) {
		    out.println("Error: Invalid date format. Please use YYYY-MM-DD.");
		    return;
		}

		int cardNo = 0;
		float balance = 0;

	    if (cardNoStr == null || cardNoStr.trim().isEmpty()) {
	        out.println("Error: Card No is required and cannot be empty.");
	        return;
	    }

	    try {
	    	cardNo = Integer.parseInt(cardNoStr);
	    } catch (NumberFormatException e) {
	        out.println("Error: Card No must be a valid number.");
	        return;
	    }
	    
	    if (balanceStr == null || balanceStr.trim().isEmpty()) {
	        out.println("Error: Balance is required and cannot be empty.");
	        return;
	    }

	    try {
	    	balance = Float.parseFloat(balanceStr);
	    } catch (NumberFormatException e) {
	        out.println("Error: Balance must be a valid number.");
	        return;
	    }
		
		
			try {
				
				psAddCard.setString(1, username);
				psAddCard.setInt(2, cardNo);
				psAddCard.setDate(3, expiryDate);
				psAddCard.setFloat(4, balance);
				
				int res = psAddCard.executeUpdate();
				
				if (res == 0) {
					out.println("<h3>Card Could Not Be Added<h3>");
				} else {
					out.println("<html></body>");
					out.println("<h3>Card Added Successfully.</h3>");
					out.println("<a href='ListCart'>Go Back To Cart</a>");
					out.println("</body></html>");
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
	}
	
	@Override
	public void destroy() {
		try {
			if (psAddCard != null) psAddCard.close();
			if (conn != null) conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
