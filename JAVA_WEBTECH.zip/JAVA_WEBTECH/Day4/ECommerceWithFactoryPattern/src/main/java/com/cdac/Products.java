package com.cdac;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet("/Products")
public class Products extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	Connection conn;
	PreparedStatement psProducts;
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		
		try {
			ServletContext context = getServletContext();
			
			String dbUrl = context.getInitParameter("dbUrl");
			String dbDriver = context.getInitParameter("dbDriver");
			String dbUser = context.getInitParameter("dbUser");
			String dbPassword = context.getInitParameter("dbPassword");
			
			Class.forName(dbDriver);
			conn = DriverManager.getConnection(dbUrl, dbUser, dbPassword);
			
			psProducts = conn.prepareStatement("select * from products where category_id=?");
		}catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
			throw new ServletException("DB Connection Issues", e);
		}
	}
 

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession(false);
		if (session == null) {
			response.sendRedirect("auth/login.html");
			return;
		} else {
			String username = (String) session.getAttribute("username");
			if (username.equals("admin")) {
				response.sendRedirect("admin/administration.html");
				return;
			}
		}
		
		PrintWriter out = response.getWriter();
		
		String username = (String) session.getAttribute("username");
		
		String categoryIdString = request.getParameter("categoryId");
	    int categoryId = 0;

	    if (categoryIdString == null || categoryIdString.trim().isEmpty()) {
	        out.println("Error: Category ID is required and cannot be empty.");
	        return;
	    }

	    try {
	        categoryId = Integer.parseInt(categoryIdString);
	    } catch (NumberFormatException e) {
	        out.println("Error: Category ID must be a valid number.");
	        return;
	    }
		
			try {
				psProducts.setInt(1, categoryId);
				
				try(ResultSet result = psProducts.executeQuery()){
					out.println("<html>");
					out.println("<body>");
					out.println("Welcome <b>"+ username +"</b><br><br>");
					out.println("<table border=1>");
					out.println("<tr>");
					out.println("<th>Product ID</th>");
					out.println("<th>Product Name</th>");
					out.println("<th>Product Description</th>");
					out.println("<th>Product Price</th>");
					out.println("<th>Product ImgUrl</th>");
					out.println("<th>Add To Cart</th>");
					out.println("</tr>");
					
				    					
					while(result.next()) {
						String productIdString = result.getString("product_id");
						int productId = 0;
						
						if (productIdString == null || productIdString.trim().isEmpty()) {
							out.println("Error: Category ID is required and cannot be empty.");
							return;
						}
						
						try {
							productId = Integer.parseInt(productIdString);
						} catch (NumberFormatException e) {
							out.println("Error: Category ID must be a valid number.");
							return;
						}
						String productName = result.getString("product_name");
						String productDesc = result.getString("product_desc");
						String productPrice = result.getString("product_price");
						String productImgUrl = result.getString("product_imgurl");
						out.println("<tr>");
						out.println("<td>"+productId+"</td>");
						out.println("<td>"+productName+"</td>");
						out.println("<td>"+productDesc+"</td>");
						out.println("<td>"+productPrice+"</td>");
						out.println("<td><img src='Images/"+productImgUrl+"' height='50px' width='50px'/></td>");
						out.println("<td><a href='AddToCart?categoryId="+categoryId+"&productId="+productId+"&productPrice="+productPrice+"'>AddToCart</a></td>");						
						out.println("</tr>");
					}
					
					out.println("</table><br>");
					out.println("<a href='ListCart'>My Cart</a><br>");
					out.println("<a href='Logout'>LogOut</a>");
					out.println("<body>");
					out.println("</html>");
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
	}
	
	@Override
	public void destroy() {
		try {
			if (psProducts != null) psProducts.close();
			if (conn != null) conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
