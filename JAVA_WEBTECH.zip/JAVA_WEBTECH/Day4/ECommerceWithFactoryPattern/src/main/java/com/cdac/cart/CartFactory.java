package com.cdac.cart;

import java.lang.reflect.Constructor;

import jakarta.servlet.ServletContext;

public class CartFactory {
    public static Cart getInstance(ServletContext context) {
        try {
            String className = context.getInitParameter("cartClass");

            if (className == null || className.isEmpty()) {
                throw new RuntimeException("Cart class name is not configured in web.xml");
            }

            Class<?> refCartClass = Class.forName(className);
            Constructor<?> refConstructor = refCartClass.getConstructor();

            return (Cart) refConstructor.newInstance();
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to create Cart instance", e);
        }
    }
}
