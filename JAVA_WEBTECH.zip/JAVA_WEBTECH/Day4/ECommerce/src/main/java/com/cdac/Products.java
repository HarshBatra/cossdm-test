package com.cdac;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet("/Products")
public class Products extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	Connection conn;
	PreparedStatement psProducts;
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		
		try {
			ServletContext context = getServletContext();
			
			String dbUrl = context.getInitParameter("dbUrl");
			String dbDriver = context.getInitParameter("dbDriver");
			String dbUser = context.getInitParameter("dbUser");
			String dbPassword = context.getInitParameter("dbPassword");
			
			Class.forName(dbDriver);
			conn = DriverManager.getConnection(dbUrl, dbUser, dbPassword);
			
			psProducts = conn.prepareStatement("select * from products where category_id=?");
		}catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
			throw new ServletException("DB Connection Issues", e);
		}
	}
 

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		
		HttpSession session = request.getSession(false);
		if (session == null) {
			response.sendRedirect("login.html");
			return;
		}
		String username = (String) session.getAttribute("username");
		
		String categoryIdString = request.getParameter("categoryId");
	    int categoryId = 0; // Default value to prevent uninitialized usage

	    // Input validation
	    if (categoryIdString == null || categoryIdString.trim().isEmpty()) {
	        out.println("Error: Category ID is required and cannot be empty.");
	        return; // Stop further processing
	    }

	    try {
	        categoryId = Integer.parseInt(categoryIdString); // Safe parsing
	    } catch (NumberFormatException e) {
	        out.println("Error: Category ID must be a valid number.");
	        return; // Stop further processing
	    }
		
			try {
				psProducts.setInt(1, categoryId);
				
				try(ResultSet result = psProducts.executeQuery()){
					out.println("<html>");
					out.println("<body>");
					out.println("Welcome <b>"+ username +"</b><br><br>");
					out.println("<table border=1>");
					out.println("<tr>");
					out.println("<th>Product ID</th>");
					out.println("<th>Product Name</th>");
					out.println("<th>Product Description</th>");
					out.println("<th>Product Price</th>");
					out.println("<th>Product ImgUrl</th>");
					out.println("</tr>");
					while(result.next()) {
						out.println("<tr>");
						out.println("<td>"+result.getString("product_id")+"</td>");
						out.println("<td>"+result.getString("product_name")+"</a></td>");
						out.println("<td>"+result.getString("product_desc")+"</a></td>");
						out.println("<td>"+result.getString("product_price")+"</a></td>");
						out.println("<td><img src='Images/"+result.getString("product_imgurl")+"' height='50px' width='50px'/></td>");
						out.println("</tr>");
						}
					out.println("</table>");
					out.println("<body>");
					out.println("</html>");
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
	}
	
	@Override
	public void destroy() {
		try {
			if (psProducts != null) psProducts.close();
			if (conn != null) conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
