package com.cdac;

import java.util.Iterator;
import java.util.Scanner;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.cdac.beans.Users;
import com.cdac.config.ApplicationConfiguration;
import com.cdac.dao.UsersDAO;

public class App 
{
    public static void main( String[] args )
    {
        try(AnnotationConfigApplicationContext appContext = new AnnotationConfigApplicationContext(ApplicationConfiguration.class);
        		Scanner sc = new Scanner(System.in)){
        	UsersDAO dao = (UsersDAO) appContext.getBean("usersDAO");
        	
        	System.out.println("Enter username, name, email, password");
        	String userName = sc.next();
        	String name = sc.next();
        	String email = sc.next();
        	String password = sc.next();
        	
        	boolean status = dao.registerUser(userName, password, name, email);
        	
        	if (status) System.out.println("User Registered");
        	
        	
        	Iterator<Users> allUsers = dao.getAllUsers();
        	while(allUsers.hasNext()) {
        		Users objUser = allUsers.next();
        		System.out.println(objUser);
        	}
        }
    }
}
