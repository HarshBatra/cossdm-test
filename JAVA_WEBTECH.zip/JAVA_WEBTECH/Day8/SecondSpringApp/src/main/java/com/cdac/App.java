package com.cdac;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.cdac.beans.Users;
import com.cdac.config.ApplicationConfiguration;

public class App 
{
    public static void main( String[] args )
    {
        try (AnnotationConfigApplicationContext appContext = new AnnotationConfigApplicationContext(ApplicationConfiguration.class)){
        	Users objUser = (Users) appContext.getBean("objUser");
        	Users objUser2 = (Users) appContext.getBean("objUser");
        	
        	objUser.setUserName("harshbatra");
        	
        	System.out.println(objUser.getUserName());
        	System.out.println(objUser.getPassword());
        	System.out.println(objUser2.getUserName());
        	System.out.println(objUser2.getPassword());
        }
    }
}
