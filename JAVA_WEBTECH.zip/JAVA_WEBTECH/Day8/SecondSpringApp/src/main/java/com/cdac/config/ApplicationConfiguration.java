package com.cdac.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.cdac.beans.Users;

@Configuration
@ComponentScan(basePackages = {"com.cdac.beans"})
public class ApplicationConfiguration {
	
	@Bean
	@Scope(scopeName = "prototype")
	public Users objUser() {
		return new Users("harsh", "harsh1234");
	}

}
