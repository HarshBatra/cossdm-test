package com.cdac.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.Scope;

import com.cdac.beans.Users;

@Configuration
@ComponentScan(basePackages = {"com.cdac"})
@PropertySource("classpath:application.properties")
public class ApplicationConfiguration {
	
//	@Bean
//	@Scope(scopeName = "prototype")
//	public Users objUser() {
//		return new Users("harsh", "harsh1234");
//	}
	
//	@Bean
//	public Users objUser(@Value("defaultUser") String user, @Value("defaultPassword") String pwd) {
//		return new Users(user,pwd);
//	}
	
	// by default the scope is singleton, due to which both objUser and objUser2 in main method will have same values
	@Bean
	public Users objUser(@Value("${default.username}") String user, @Value("${default.password}") String pwd) {
		return new Users(user,pwd);
	}

}
